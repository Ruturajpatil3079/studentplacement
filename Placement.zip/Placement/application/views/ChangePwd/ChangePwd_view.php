
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                <div class="breadcrumb">
                    <h1>Change Password</h1>
                   
                </div>
                <div class="separator-breadcrumb border-top"></div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">
                                        <div class="col-md-3 form-group mb-3">
                                            <label for="firstName1">Enter Old Password</label>
                                            <input class="form-control" id="oldpwd" type="text" placeholder="Enter Old Password" name="oldpwd" value="" />
                                        </div>

                                        <div class="col-md-3 form-group mb-3">
                                            <label for="firstName1">Enter New Password</label>
                                            <input class="form-control" id="newpwd" type="text" placeholder="Enter New Password" name="newpwd" value="" />
                                        </div>

                                        <div class="col-md-3 form-group mb-3">
                                            <label for="firstName1">Enter Confirm Password</label>
                                            <input class="form-control" id="comfirmpwd" type="text" placeholder="Enter Confirm Password" name="comfirmpwd" value="" />
                                        </div>
                                       
                                      
                                      
                                        
                                        
                                        
                                        <div class="col-md-12 text-right">
                                            <button class="btn btn-primary" type="button" name="btn_save" id="btn_save">Submit</button>
                                            <button class="btn btn-warning text-white" type="button" name="cancle" id="cancle">Cancle</button>

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/BranchCreate.js"></script>
                   
                       
               
            